/* USER CODE BEGIN Header */ // Poprawiono
/*
@file           : main.c
@brief          : Main program body
@attention
Copyright (c) 2025 STMicroelectronics.
All rights reserved.
This software is licensed under terms that can be found in the LICENSE file
in the root directory of this software component.
If no LICENSE file comes with this software, it is provided AS-IS.
*/
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <string.h> 	  	 // Dla memset
#include "ssd1306.h"      	// Główny plik nagłówkowy biblioteki
#include "ssd1306_fonts.h" // Plik z czcionkami
#include <stdbool.h> 	  // Dla typu bool

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

// Stany omijania przeszkody
typedef enum {
    OMIJANE_BRAK,
    OMIJANE_START,
    OMIJANE_COFANIE,
    OMIJANE_SKRET_LEWO,
    OMIJANE_KONIEC
} StanOmijania_t;

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

// Ustawienia unikania przeszkody
#define COFANIE_CZAS_MS 800
#define SKRET_CZAS_MS 800
#define COFANIE_PREDKOSC 800
#define SKRET_PREDKOSC 800
#define PAUZA_PRZED_MANEWREM_MS 100

#define PROG_DYSTANS_CM 30.0f
#define MAX_PWM 900

#define OLED_UPDATE_MS 2000
#define HCSR04_POMIAR_MS 70

// Definicje dla ledow
#define LICZBA_DIOD 16
#define PWM_WYSOKI_PULS 58
#define PWM_NISKI_PULS  29
#define DLUGOSC_RESETU_LED 60

// Tryby pracy LED
#define LED_TRYB_WYLACZONY 0
#define LED_TRYB_1 1
#define LED_TRYB_3 3

// Parametry animacji 1
#define ANIM_1_JASNOSC 10
#define ANIM_1_NASYCENIE 255
#define ANIM_1_ILE_DIOD_PIERSCIEN 8
#define ANIM_1_DELAY_MS 50
#define ANIM_1_KROK_BARWY 10
#define ANIM_1_DLUGOSC_OGONA 3

// Parametry animacji 3
#define ANIM_3_BARWA_NORMALNA 120 // Zielony
#define ANIM_3_NASYCENIE 255
#define ANIM_3_JASNOSC 30
#define ANIM_3_ILE_DIOD 3
#define ANIM_3_DELAY_MS 70

#define BARWA_OMIJANE_PRZESZKODY 0 // Czerwony

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
I2C_HandleTypeDef hi2c1;

TIM_HandleTypeDef htim1;
TIM_HandleTypeDef htim2;
TIM_HandleTypeDef htim3;
DMA_HandleTypeDef hdma_tim1_ch1;

UART_HandleTypeDef huart2;

/* USER CODE BEGIN PV */

uint16_t pwm_buf_led[LICZBA_DIOD * 24 + DLUGOSC_RESETU_LED];
volatile bool wyslano_dane_do_led = true;

volatile uint8_t tryb_robota = 1;
volatile uint8_t led_tryb = LED_TRYB_WYLACZONY;
uint8_t odebrana_komenda_uart;

volatile StanOmijania_t stan_omijania = OMIJANE_BRAK;
uint32_t czas_startu_etapu_omijania = 0;

uint8_t anim1_idx = 0;
uint16_t anim1_barwa = 0;
int8_t anim3_pozycja = 0;
int8_t anim3_kierunek = 1;

volatile uint32_t echo_poczatek_us = 0;
volatile uint32_t echo_koniec_us = 0;
volatile bool echo_trwa_pomiar = false;
volatile float dystans_cm = 0.0f;
volatile bool jest_nowy_dystans = false;

char* oled_teksty[] = { "21227", "21319", "21255" };
uint8_t oled_idx_tekstu = 0;
const uint8_t OLED_LICZBA_TEKSTOW = sizeof(oled_teksty) / sizeof(oled_teksty[0]);
uint32_t oled_czas_ost_aktualizacji = 0;
uint32_t hcsr04_czas_ost_pomiaru = 0;
uint32_t led_czas_ost_aktualizacji = 0;

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/

void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_DMA_Init(void);
static void MX_TIM1_Init(void);
static void MX_I2C1_Init(void);
static void MX_TIM2_Init(void);
static void MX_TIM3_Init(void);
static void MX_USART2_UART_Init(void);

/* USER CODE BEGIN PFP */

void led_ustaw_rgb(uint8_t idx, uint8_t r, uint8_t g, uint8_t b);
void led_ustaw_hsv(uint8_t idx, uint16_t h, uint8_t s, uint8_t v);
void led_ustaw_wszystkie_rgb(uint8_t r, uint8_t g, uint8_t b);
void led_ustaw_wszystkie_hsv(uint16_t h, uint8_t s, uint8_t v);
void hsv_do_rgb(uint16_t h, uint8_t s, uint8_t v, uint8_t* r, uint8_t* g, uint8_t* b);
void led_wyczysc_bufor(void);
void led_pokaz(void);
void led_wylacz_wszystkie(void);

void CofajSkrecajPrawo(uint16_t pwm_cofania);
void ZatrzymajSilniki(void);
void JedzDoPrzodu(uint16_t pwm);
void JedzDoTylu(uint16_t pwm);
void SkrecWPrawo(uint16_t pwm);
void SkrecWLewo(uint16_t pwm);

void HCSR04_Trigger(void);
void Delay_us(uint32_t us);

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

void Delay_us(uint32_t us) {
    if (!(DWT->CTRL & DWT_CTRL_CYCCNTENA_Msk)) {
        CoreDebug->DEMCR |= CoreDebug_DEMCR_TRCENA_Msk;
        DWT->CYCCNT = 0;
        DWT->CTRL |= DWT_CTRL_CYCCNTENA_Msk;
    }
    uint32_t start_tick = DWT->CYCCNT;
    uint32_t delay_ticks = us * (SystemCoreClock / 1000000);
    while ((DWT->CYCCNT - start_tick) < delay_ticks);
}

void ZatrzymajSilniki(void) {
	__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_1, 0);
	__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_2, 0);
	__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_3, 0);
	__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_4, 0);
}

void JedzDoPrzodu(uint16_t pwm) {
	if (pwm > MAX_PWM) pwm = MAX_PWM;
		__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_3, pwm);
		__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_4, 0);
		__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_1, pwm);
		__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_2, 0);
}

void JedzDoTylu(uint16_t pwm) {
	if (pwm > MAX_PWM) pwm = MAX_PWM;
		__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_3, 0);
		__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_4, pwm);
		__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_1, 0);
		__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_2, pwm);
}

void SkrecWLewo(uint16_t pwm) {
	if (pwm > MAX_PWM) pwm = MAX_PWM;
		__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_3, pwm);
		__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_4, 0);
		__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_1, 0);
		__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_2, 0);
}

void SkrecWPrawo(uint16_t pwm) {
	if (pwm > MAX_PWM) pwm = MAX_PWM;
		__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_3, 0);
		__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_4, 0);
		__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_1, pwm);
		__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_2, 0);
}

void CofajSkrecajPrawo(uint16_t pwm_cofania){
	if (pwm_cofania > MAX_PWM) pwm_cofania = MAX_PWM;
		__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_1, 0);
		__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_2, pwm_cofania);
		__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_3, 0);
		__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_4, 0);
}


void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart) {
	if (huart->Instance == USART2) {
		switch(odebrana_komenda_uart) {
			case 'a':
			tryb_robota = 0;
			ZatrzymajSilniki();
			stan_omijania = OMIJANE_BRAK; // Zresetuj maszynę stanów
			jest_nowy_dystans = false;
			if (!echo_trwa_pomiar) {
				HCSR04_Trigger();
				hcsr04_czas_ost_pomiaru = HAL_GetTick();
			}
			break;
			case 'm':
			tryb_robota = 1;
			ZatrzymajSilniki();
			stan_omijania = OMIJANE_BRAK;
			break;
			case 'f': if (tryb_robota == 1) JedzDoPrzodu(700); break;
			case 'b': if (tryb_robota == 1) JedzDoTylu(700); break;
			case 'r': if (tryb_robota == 1) SkrecWPrawo(700); break;
			case 'l': if (tryb_robota == 1) SkrecWLewo(700); break;
			case 's': if (tryb_robota == 1) ZatrzymajSilniki(); break;
			case '4': if (tryb_robota == 1) JedzDoTylu(900); break;
			case '5': if (tryb_robota == 1) JedzDoPrzodu(600); break;
			case '9': if (tryb_robota == 1) JedzDoPrzodu(900); break;

					case 'O': led_tryb = LED_TRYB_WYLACZONY; led_wylacz_wszystkie(); break;
					case '1': led_tryb = LED_TRYB_1; anim1_idx = 0; anim1_barwa = 0; break;
					case '3': led_tryb = LED_TRYB_3; anim3_pozycja = 0; anim3_kierunek = 1; break;

					default: break;
			}
		HAL_UART_Receive_IT(&huart2, &odebrana_komenda_uart, 1);
	}
}

void HCSR04_Trigger(void) {
	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4, GPIO_PIN_RESET); Delay_us(2);
	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4, GPIO_PIN_SET);   Delay_us(10);
	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4, GPIO_PIN_RESET);
	echo_trwa_pomiar = false;
	jest_nowy_dystans = false;
}

void HAL_TIM_IC_CaptureCallback(TIM_HandleTypeDef *htim) {
if (htim->Instance == TIM2 && htim->Channel == HAL_TIM_ACTIVE_CHANNEL_2) {
	if (!echo_trwa_pomiar) {
		echo_poczatek_us = HAL_TIM_ReadCapturedValue(htim, TIM_CHANNEL_2);
		echo_trwa_pomiar = true;
		__HAL_TIM_SET_CAPTUREPOLARITY(htim, TIM_CHANNEL_2, TIM_INPUTCHANNELPOLARITY_FALLING);
	} else {
		echo_koniec_us = HAL_TIM_ReadCapturedValue(htim, TIM_CHANNEL_2);
		uint32_t roznica_us;
		if (echo_koniec_us >= echo_poczatek_us) {
			roznica_us = echo_koniec_us - echo_poczatek_us;
		} else {
			roznica_us = (0xFFFFFFFF - echo_poczatek_us) + echo_koniec_us + 1;
		}
		dystans_cm = (float)roznica_us * 0.01715f;
		jest_nowy_dystans = true;
		echo_trwa_pomiar = false;
		__HAL_TIM_SET_CAPTUREPOLARITY(htim, TIM_CHANNEL_2, TIM_INPUTCHANNELPOLARITY_RISING);
	}
}
}
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
   HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_TIM1_Init();
  MX_I2C1_Init();
  MX_TIM2_Init();
  MX_TIM3_Init();
  MX_USART2_UART_Init();
  /* USER CODE BEGIN 2 */

  memset(pwm_buf_led, 0, sizeof(pwm_buf_led));
  led_pokaz();
  HAL_Delay(1);

  ssd1306_Init();

  HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_1);
  HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_2);
  HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_3);
  HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_4);

  HAL_TIM_IC_Start_IT(&htim2, TIM_CHANNEL_2);

  tryb_robota = 1;
  led_tryb = LED_TRYB_WYLACZONY;
  stan_omijania = OMIJANE_BRAK;
  HAL_UART_Receive_IT(&huart2, &odebrana_komenda_uart, 1);

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
  /* USER CODE END WHILE */

  /* USER CODE BEGIN 3 */

  uint32_t teraz_ms = HAL_GetTick();
  uint32_t anim_delay_ms;
  bool czy_omijanie_aktywne_dla_led = (tryb_robota == 0 && stan_omijania != OMIJANE_BRAK && stan_omijania != OMIJANE_KONIEC);


  // --- Sterowanie LED ---
      switch(led_tryb) {
          case LED_TRYB_1: anim_delay_ms = ANIM_1_DELAY_MS; break;
          case LED_TRYB_3: anim_delay_ms = ANIM_3_DELAY_MS; break;
          default:         anim_delay_ms = 500; break;
      }

      if (wyslano_dane_do_led && (teraz_ms - led_czas_ost_aktualizacji >= anim_delay_ms)) {
    	  led_czas_ost_aktualizacji = teraz_ms;
          bool aktualizuj_led = false;

          if (led_tryb != LED_TRYB_WYLACZONY) {
              led_wyczysc_bufor();
          }

          uint16_t aktualna_barwa_anim1 = anim1_barwa;
          uint16_t aktualna_barwa_anim3 = ANIM_3_BARWA_NORMALNA;

          if (czy_omijanie_aktywne_dla_led) {
              aktualna_barwa_anim1 = BARWA_OMIJANE_PRZESZKODY;
              aktualna_barwa_anim3 = BARWA_OMIJANE_PRZESZKODY;
          }


          switch (led_tryb) {
              case LED_TRYB_WYLACZONY:
                  break;

              case LED_TRYB_1:
                  for (int i = 0; i < ANIM_1_DLUGOSC_OGONA; i++) {
                      int led_pos = (anim1_idx - i + ANIM_1_ILE_DIOD_PIERSCIEN) % ANIM_1_ILE_DIOD_PIERSCIEN;
                      uint8_t jas = ANIM_1_JASNOSC / (i + 1);
                      jas = (jas == 0 && i == 0 && ANIM_1_JASNOSC > 0) ? 1 : ((jas < 1 && i > 0) ? 0 : jas);

                      if (jas > 0) {
                          led_ustaw_hsv(led_pos, aktualna_barwa_anim1, ANIM_1_NASYCENIE, jas);
                          led_ustaw_hsv(led_pos + ANIM_1_ILE_DIOD_PIERSCIEN, aktualna_barwa_anim1, ANIM_1_NASYCENIE, jas);
                      }
                  }
                  anim1_idx = (anim1_idx + 1) % ANIM_1_ILE_DIOD_PIERSCIEN;
                  anim1_barwa = (anim1_barwa + ANIM_1_KROK_BARWY) % 360;
                  aktualizuj_led = true;
                  break;

              case LED_TRYB_3:
                  for (int i = 0; i < ANIM_3_ILE_DIOD; i++) {
                      int led_idx = anim3_pozycja + i;
                      if (led_idx >= 0 && led_idx < LICZBA_DIOD) {
                          uint8_t jas = ANIM_3_JASNOSC;
                          if (ANIM_3_ILE_DIOD > 1 && (i == 0 || i == ANIM_3_ILE_DIOD - 1)) {
                              jas /= 2;
                          }
                          if (jas == 0 && ANIM_3_JASNOSC > 0) jas = 1;

                          if (jas > 0) {
                            led_ustaw_hsv(led_idx, aktualna_barwa_anim3, ANIM_3_NASYCENIE, jas);
                          }
                      }
                  }
                  anim3_pozycja += anim3_kierunek;
                  if (anim3_pozycja + ANIM_3_ILE_DIOD > LICZBA_DIOD) {
                      anim3_kierunek = -1;
                      anim3_pozycja = LICZBA_DIOD - ANIM_3_ILE_DIOD;
                  } else if (anim3_pozycja < 0) {
                      anim3_kierunek = 1;
                      anim3_pozycja = 0;
                  }
                  aktualizuj_led = true;
                  break;
          }
          if (aktualizuj_led) {
        	  led_pokaz();
          }
      }


     // --- Obsługa wyświetlacza OLED ---
     if (teraz_ms - oled_czas_ost_aktualizacji >= OLED_UPDATE_MS) {
         oled_czas_ost_aktualizacji = teraz_ms;
         ssd1306_Fill(Black);

         char tekst_autorzy[] = "Autorzy:";
         uint8_t szer_autorzy = strlen(tekst_autorzy) * Font_11x18.width;
         ssd1306_SetCursor((SSD1306_WIDTH - szer_autorzy) / 2, 8);
         ssd1306_WriteString(tekst_autorzy, Font_11x18, White);

         char* tekst_indeks = oled_teksty[oled_idx_tekstu];
         uint8_t szer_indeks = strlen(tekst_indeks) * Font_16x26.width;
         ssd1306_SetCursor((SSD1306_WIDTH - szer_indeks) / 2, 8 + Font_11x18.height + 4);
         ssd1306_WriteString(tekst_indeks, Font_16x26, White);

         ssd1306_UpdateScreen();
         oled_idx_tekstu = (oled_idx_tekstu + 1) % OLED_LICZBA_TEKSTOW;
     }

     // --- Logika ruchu robota i HC-SR04 ---
     if (tryb_robota == 0) {
         if (stan_omijania == OMIJANE_BRAK || stan_omijania == OMIJANE_KONIEC) {
             if (!echo_trwa_pomiar && (teraz_ms - hcsr04_czas_ost_pomiaru >= HCSR04_POMIAR_MS)) {
                 HCSR04_Trigger();
                 hcsr04_czas_ost_pomiaru = teraz_ms;
             }
         }


         // Maszyna stanów omijania przeszkody
         switch (stan_omijania) {
             case OMIJANE_BRAK:
                 if (jest_nowy_dystans) {
                     jest_nowy_dystans = false;
                     if (dystans_cm <= PROG_DYSTANS_CM && dystans_cm > 0.5f) {
                         stan_omijania = OMIJANE_START; // Rozpocznij manewr
                         czas_startu_etapu_omijania = teraz_ms;
                         ZatrzymajSilniki();
                     } else {
                         JedzDoPrzodu(MAX_PWM);
                     }
                 } else if (!echo_trwa_pomiar) { // Jeśli nie ma nowego dystansu i pomiar zakończony
                     JedzDoPrzodu(MAX_PWM);       // Kontynuuj jazdę
                 }
                 break;

             case OMIJANE_START: // Pauza przed manewrem
                 if (teraz_ms - czas_startu_etapu_omijania >= PAUZA_PRZED_MANEWREM_MS) {
                     stan_omijania = OMIJANE_COFANIE;
                     czas_startu_etapu_omijania = teraz_ms;
                     CofajSkrecajPrawo(COFANIE_PREDKOSC);
                 }
                 break;

             case OMIJANE_COFANIE:
                 if (teraz_ms - czas_startu_etapu_omijania >= COFANIE_CZAS_MS) {
                     stan_omijania = OMIJANE_SKRET_LEWO;
                     czas_startu_etapu_omijania = teraz_ms;
                     SkrecWLewo(SKRET_PREDKOSC);
                 }
                 break;

             case OMIJANE_SKRET_LEWO:
                 if (teraz_ms - czas_startu_etapu_omijania >= SKRET_CZAS_MS) {
                     stan_omijania = OMIJANE_KONIEC;
                     ZatrzymajSilniki();
                     // Wymuś nowy pomiar po manewrze
                     if (!echo_trwa_pomiar) {
                         HCSR04_Trigger();
                         hcsr04_czas_ost_pomiaru = HAL_GetTick();
                     }
                 }
                 break;

            case OMIJANE_KONIEC:
                stan_omijania = OMIJANE_BRAK;
                break;
         }
     }
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
  RCC_PeriphCLKInitTypeDef PeriphClkInit = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI|RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_BYPASS;
  RCC_OscInitStruct.HSEPredivValue = RCC_HSE_PREDIV_DIV1;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL9;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
  PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_USART2|RCC_PERIPHCLK_I2C1
                              |RCC_PERIPHCLK_TIM1;
  PeriphClkInit.Usart2ClockSelection = RCC_USART2CLKSOURCE_PCLK1;
  PeriphClkInit.I2c1ClockSelection = RCC_I2C1CLKSOURCE_HSI;
  PeriphClkInit.Tim1ClockSelection = RCC_TIM1CLK_HCLK;
  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief I2C1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_I2C1_Init(void)
{

  /* USER CODE BEGIN I2C1_Init 0 */

  /* USER CODE END I2C1_Init 0 */

  /* USER CODE BEGIN I2C1_Init 1 */

  /* USER CODE END I2C1_Init 1 */
  hi2c1.Instance = I2C1;
  hi2c1.Init.Timing = 0x0010020A;
  hi2c1.Init.OwnAddress1 = 0;
  hi2c1.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  hi2c1.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c1.Init.OwnAddress2 = 0;
  hi2c1.Init.OwnAddress2Masks = I2C_OA2_NOMASK;
  hi2c1.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c1.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
  if (HAL_I2C_Init(&hi2c1) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Analogue filter
  */
  if (HAL_I2CEx_ConfigAnalogFilter(&hi2c1, I2C_ANALOGFILTER_ENABLE) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Digital filter
  */
  if (HAL_I2CEx_ConfigDigitalFilter(&hi2c1, 0) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN I2C1_Init 2 */

  /* USER CODE END I2C1_Init 2 */

}

/**
  * @brief TIM1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM1_Init(void)
{

  /* USER CODE BEGIN TIM1_Init 0 */

  /* USER CODE END TIM1_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_OC_InitTypeDef sConfigOC = {0};
  TIM_BreakDeadTimeConfigTypeDef sBreakDeadTimeConfig = {0};

  /* USER CODE BEGIN TIM1_Init 1 */

  /* USER CODE END TIM1_Init 1 */
  htim1.Instance = TIM1;
  htim1.Init.Prescaler = 0;
  htim1.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim1.Init.Period = 89;
  htim1.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim1.Init.RepetitionCounter = 0;
  htim1.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim1) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim1, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_Init(&htim1) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterOutputTrigger2 = TIM_TRGO2_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim1, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = 0;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCNPolarity = TIM_OCNPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  sConfigOC.OCIdleState = TIM_OCIDLESTATE_RESET;
  sConfigOC.OCNIdleState = TIM_OCNIDLESTATE_RESET;
  if (HAL_TIM_PWM_ConfigChannel(&htim1, &sConfigOC, TIM_CHANNEL_1) != HAL_OK)
  {
    Error_Handler();
  }
  sBreakDeadTimeConfig.OffStateRunMode = TIM_OSSR_DISABLE;
  sBreakDeadTimeConfig.OffStateIDLEMode = TIM_OSSI_DISABLE;
  sBreakDeadTimeConfig.LockLevel = TIM_LOCKLEVEL_OFF;
  sBreakDeadTimeConfig.DeadTime = 0;
  sBreakDeadTimeConfig.BreakState = TIM_BREAK_DISABLE;
  sBreakDeadTimeConfig.BreakPolarity = TIM_BREAKPOLARITY_HIGH;
  sBreakDeadTimeConfig.BreakFilter = 0;
  sBreakDeadTimeConfig.Break2State = TIM_BREAK2_DISABLE;
  sBreakDeadTimeConfig.Break2Polarity = TIM_BREAK2POLARITY_HIGH;
  sBreakDeadTimeConfig.Break2Filter = 0;
  sBreakDeadTimeConfig.AutomaticOutput = TIM_AUTOMATICOUTPUT_DISABLE;
  if (HAL_TIMEx_ConfigBreakDeadTime(&htim1, &sBreakDeadTimeConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM1_Init 2 */

  /* USER CODE END TIM1_Init 2 */
  HAL_TIM_MspPostInit(&htim1);

}

/**
  * @brief TIM2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM2_Init(void)
{

  /* USER CODE BEGIN TIM2_Init 0 */

  /* USER CODE END TIM2_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_IC_InitTypeDef sConfigIC = {0};

  /* USER CODE BEGIN TIM2_Init 1 */

  /* USER CODE END TIM2_Init 1 */
  htim2.Instance = TIM2;
  htim2.Init.Prescaler = 71;
  htim2.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim2.Init.Period = 0xFFFFFFFF;
  htim2.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim2.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim2) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim2, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_IC_Init(&htim2) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim2, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigIC.ICPolarity = TIM_INPUTCHANNELPOLARITY_RISING;
  sConfigIC.ICSelection = TIM_ICSELECTION_DIRECTTI;
  sConfigIC.ICPrescaler = TIM_ICPSC_DIV1;
  sConfigIC.ICFilter = 0;
  if (HAL_TIM_IC_ConfigChannel(&htim2, &sConfigIC, TIM_CHANNEL_2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM2_Init 2 */

  /* USER CODE END TIM2_Init 2 */

}

/**
  * @brief TIM3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM3_Init(void)
{

  /* USER CODE BEGIN TIM3_Init 0 */

  /* USER CODE END TIM3_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_OC_InitTypeDef sConfigOC = {0};

  /* USER CODE BEGIN TIM3_Init 1 */

  /* USER CODE END TIM3_Init 1 */
  htim3.Instance = TIM3;
  htim3.Init.Prescaler = 71;
  htim3.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim3.Init.Period = 999;
  htim3.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim3.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim3) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim3, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_Init(&htim3) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim3, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = 0;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  if (HAL_TIM_PWM_ConfigChannel(&htim3, &sConfigOC, TIM_CHANNEL_1) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_ConfigChannel(&htim3, &sConfigOC, TIM_CHANNEL_2) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_ConfigChannel(&htim3, &sConfigOC, TIM_CHANNEL_3) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_ConfigChannel(&htim3, &sConfigOC, TIM_CHANNEL_4) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM3_Init 2 */

  /* USER CODE END TIM3_Init 2 */
  HAL_TIM_MspPostInit(&htim3);

}

/**
  * @brief USART2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART2_UART_Init(void)
{

  /* USER CODE BEGIN USART2_Init 0 */

  /* USER CODE END USART2_Init 0 */

  /* USER CODE BEGIN USART2_Init 1 */

  /* USER CODE END USART2_Init 1 */
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 9600;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  huart2.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart2.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART2_Init 2 */

  /* USER CODE END USART2_Init 2 */

}

/**
  * Enable DMA controller clock
  */
static void MX_DMA_Init(void)
{

  /* DMA controller clock enable */
  __HAL_RCC_DMA1_CLK_ENABLE();

  /* DMA interrupt init */
  /* DMA1_Channel2_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA1_Channel2_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(DMA1_Channel2_IRQn);

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  /* USER CODE BEGIN MX_GPIO_Init_0 */
  /* USER CODE END MX_GPIO_Init_0 */

  GPIO_InitTypeDef GPIO_InitStruct = {0};

  /* USER CODE BEGIN MX_GPIO_Init_1 */
  /* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOF_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4, GPIO_PIN_RESET);

  /*Configure GPIO pin : PA4 - HC-SR04 Trigger */
  GPIO_InitStruct.Pin = GPIO_PIN_4;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /* USER CODE BEGIN MX_GPIO_Init_2 */
  /* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */

void led_wyczysc_bufor(void) {
	for (int i = 0; i < LICZBA_DIOD * 24; i++) {
		pwm_buf_led[i] = PWM_NISKI_PULS;
	}
}

void led_ustaw_rgb(uint8_t idx, uint8_t r, uint8_t g, uint8_t b) {
	if (idx >= LICZBA_DIOD) return;

	uint8_t kolory[3] = {g, r, b};
	uint16_t *pwm_ptr = &pwm_buf_led[idx * 24];

	for (int i = 0; i < 3; i++) {
		for (int j = 7; j >= 0; j--) {
			if ((kolory[i] >> j) & 1) {
				*pwm_ptr++ = PWM_WYSOKI_PULS;
			} else {
				*pwm_ptr++ = PWM_NISKI_PULS;
		}
	}
	}
}

void led_ustaw_hsv(uint8_t idx, uint16_t h, uint8_t s, uint8_t v) {
	if (idx >= LICZBA_DIOD) return;
	uint8_t r, g, b;
	hsv_do_rgb(h, s, v, &r, &g, &b);
	led_ustaw_rgb(idx, r, g, b);
}

void led_ustaw_wszystkie_rgb(uint8_t r, uint8_t g, uint8_t b) {
	for (uint8_t i = 0; i < LICZBA_DIOD; i++) {
		led_ustaw_rgb(i, r, g, b);
	}
}

void led_ustaw_wszystkie_hsv(uint16_t h, uint8_t s, uint8_t v) {
	for (uint8_t i = 0; i < LICZBA_DIOD; i++) {
		led_ustaw_hsv(i, h, s, v);
	}
}

void hsv_do_rgb(uint16_t h, uint8_t s, uint8_t v_in, uint8_t* r_out, uint8_t* g_out, uint8_t* b_out) {
    uint8_t r, g, b;
    if (s == 0) {
        r = g = b = v_in;
    } else {
        uint8_t region = h / 60;
        uint16_t remainder = (h % 60) * 255 / 60;

        uint8_t p = (uint8_t)((v_in * (255 - s)) / 255);
        uint8_t q = (uint8_t)((v_in * (255 - (s * remainder) / 255)) / 255);
        uint8_t t = (uint8_t)((v_in * (255 - (s * (255 - remainder)) / 255)) / 255);

        switch (region) {
            case 0:  r = v_in; g = t;    b = p;    break;
            case 1:  r = q;    g = v_in; b = p;    break;
            case 2:  r = p;    g = v_in; b = t;    break;
            case 3:  r = p;    g = q;    b = v_in; break;
            case 4:  r = t;    g = p;    b = v_in; break;
            default: r = v_in; g = p;    b = q;    break;
        }
    }
    *r_out = r;
    *g_out = g;
    *b_out = b;
}

void led_pokaz(void) {
	if (!wyslano_dane_do_led) {
		return;
	}
	wyslano_dane_do_led = false;

	uint16_t *reset_ptr = &pwm_buf_led[LICZBA_DIOD * 24];
	for (int i = 0; i < DLUGOSC_RESETU_LED; i++) {
		reset_ptr[i] = 0;
	}

	if (HAL_TIM_PWM_Start_DMA(&htim1, TIM_CHANNEL_1, (uint32_t *)pwm_buf_led, LICZBA_DIOD * 24 + DLUGOSC_RESETU_LED) != HAL_OK) {
		wyslano_dane_do_led = true;
		Error_Handler();
	}
}

void led_wylacz_wszystkie(void) {
	led_wyczysc_bufor();
	led_pokaz();
}

void HAL_TIM_PWM_PulseFinishedCallback(TIM_HandleTypeDef *htim) {
    if (htim->Instance == TIM1) {
        HAL_TIM_PWM_Stop_DMA(htim, TIM_CHANNEL_1);
        wyslano_dane_do_led = true;
    }
}

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
